module prog4

go 1.22.2
